export type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LATE' | 'EXCUSED';

export type Student = {
  id: string;
  studentNo: string;
  firstName: string;
  lastName: string;
  fullName: string;
  email?: string;
};

export type Classroom = {
  id: string;
  gradeLevel: number;
  section: string;
  subject: string;
  room: string;
  scheduleDay: string;
  startTime: string;
  endTime: string;
  studentCount: number;
  displayName: string;
};

export type Attendance = { id: string; date: string; checkedAt?: string; status: AttendanceStatus };
export type Grade = { id: string; quarter: number; quiz: number; activity: number; exam: number; finalGrade: number };
export type RosterStudent = { student: Student; attendance?: Attendance; grade?: Grade };
