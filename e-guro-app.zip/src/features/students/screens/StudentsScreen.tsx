import { useQuery } from '@apollo/client';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, EmptyState, ErrorState, LoadingState } from '@/shared/components/ui';
import { STUDENTS_QUERY } from '../graphql/queries/getStudents';
import { colors } from '@/core/theme';
import { Student } from '@/core/types';

export default function StudentsScreen() {
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState('');
  const { data, loading, error, refetch } = useQuery<{ students: Student[] }>(STUDENTS_QUERY, { variables: { search: search || null } });
  return <View style={[styles.screen, { paddingTop: insets.top }]}>
    <View style={styles.heading}><Text style={styles.eyebrow}>DIRECTORY</Text><Text style={styles.title}>Students</Text></View>
    <View style={styles.search}><Ionicons name="search" size={19} color={colors.muted} /><TextInput value={search} onChangeText={setSearch} placeholder="Search name or student ID" placeholderTextColor="#98A2B3" style={styles.input} autoCorrect={false} /></View>
    {loading && !data ? <LoadingState /> : error && !data ? <ErrorState message={error.message} retry={refetch} /> :
      <FlatList data={data?.students} keyExtractor={(item) => item.id} contentContainerStyle={styles.list} keyboardShouldPersistTaps="handled" onRefresh={refetch} refreshing={loading}
        ListEmptyComponent={<EmptyState title="No students found" detail="Try a different name or student number." />}
        renderItem={({ item, index }) => <Pressable onPress={() => router.push(`/student/${item.id}`)} style={[styles.row, index === 0 && styles.first]}><Avatar name={item.fullName} /><View style={styles.copy}><Text style={styles.name}>{item.fullName}</Text><Text style={styles.id}>ID: {item.studentNo}</Text></View><Ionicons name="chevron-forward" size={20} color="#ABB5C3" /></Pressable>} />}
  </View>;
}

const styles = StyleSheet.create({ screen: { flex: 1, backgroundColor: colors.background }, heading: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 14 }, eyebrow: { color: colors.primary, fontSize: 10, letterSpacing: 1.5, fontWeight: '800' }, title: { fontSize: 27, fontWeight: '800', color: colors.text, marginTop: 2 }, search: { marginHorizontal: 16, marginBottom: 13, height: 46, borderRadius: 13, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }, input: { flex: 1, marginLeft: 9, color: colors.text, fontSize: 14 }, list: { marginHorizontal: 16, backgroundColor: colors.surface, borderRadius: 16, paddingHorizontal: 14, paddingBottom: 20, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' }, row: { minHeight: 69, flexDirection: 'row', alignItems: 'center', borderTopWidth: 1, borderTopColor: colors.border }, first: { borderTopWidth: 0 }, copy: { flex: 1, marginLeft: 12 }, name: { color: colors.text, fontWeight: '700', fontSize: 14 }, id: { color: colors.muted, fontSize: 11, marginTop: 4 } });
