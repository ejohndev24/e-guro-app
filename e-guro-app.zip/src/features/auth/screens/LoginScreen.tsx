import { useMutation } from '@apollo/client';
import { Ionicons } from '@expo/vector-icons';
import * as SecureStore from 'expo-secure-store';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/core/auth/AuthProvider';
import { CHANGE_PASSWORD_MUTATION, LOGIN_MUTATION } from '../graphql/mutations/authMutations';
import { colors } from '@/core/theme';

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const { signIn } = useAuth();
  const [email, setEmail] = useState('alex.rivera@school.edu');
  const [password, setPassword] = useState('Teacher123!');
  const [newPassword, setNewPassword] = useState('');
  const [pendingToken, setPendingToken] = useState<string>();
  const [login, loginState] = useMutation(LOGIN_MUTATION);
  const [change, changeState] = useMutation(CHANGE_PASSWORD_MUTATION);

  async function submitLogin() {
    const result = await login({ variables: { email, password } });
    const payload = result.data?.login;
    if (!payload) return;
    if (payload.user.mustChangePassword) {
      await SecureStore.setItemAsync('teacher-hub-token', payload.accessToken);
      setPendingToken(payload.accessToken);
    } else await signIn(payload.accessToken);
  }

  async function submitChange() {
    if (!pendingToken) return;
    await change({ variables: { currentPassword: password, newPassword } });
    await signIn(pendingToken);
  }

  const changing = Boolean(pendingToken);
  return <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={[styles.screen, { paddingTop: insets.top }]}><View style={styles.hero}><View style={styles.logo}><Ionicons name="school" size={31} color="#fff" /></View><Text style={styles.brand}>Teacher Hub</Text><Text style={styles.tagline}>{changing ? 'Secure your new account' : 'Your classroom, organized.'}</Text></View><View style={styles.card}><Text style={styles.eyebrow}>{changing ? 'FIRST SIGN-IN' : 'TEACHER SIGN-IN'}</Text><Text style={styles.title}>{changing ? 'Choose a new password' : 'Welcome back'}</Text><Text style={styles.help}>{changing ? 'Replace the temporary password sent to your email.' : 'Use your school email and password to continue.'}</Text>{!changing ? <><Field icon="mail-outline" placeholder="Email address" value={email} setValue={setEmail} /><Field icon="lock-closed-outline" placeholder="Password" value={password} setValue={setPassword} secure /><ErrorText error={loginState.error?.message} /><Pressable disabled={loginState.loading} onPress={submitLogin} style={styles.button}><Text style={styles.buttonText}>{loginState.loading ? 'Signing in…' : 'Sign in'}</Text></Pressable></> : <><Field icon="shield-checkmark-outline" placeholder="New password (10+ characters)" value={newPassword} setValue={setNewPassword} secure /><ErrorText error={changeState.error?.message} /><Pressable disabled={changeState.loading || newPassword.length < 10} onPress={submitChange} style={[styles.button, newPassword.length < 10 && { opacity: .5 }]}><Text style={styles.buttonText}>{changeState.loading ? 'Updating…' : 'Set password and continue'}</Text></Pressable></>}</View><Text style={styles.footer}>Contact your school administrator if you need access.</Text></KeyboardAvoidingView>;
}

function Field({ icon, placeholder, value, setValue, secure }: { icon: keyof typeof Ionicons.glyphMap; placeholder: string; value: string; setValue: (v: string) => void; secure?: boolean }) { return <View style={styles.field}><Ionicons name={icon} size={19} color={colors.muted} /><TextInput value={value} onChangeText={setValue} placeholder={placeholder} placeholderTextColor="#98A2B3" autoCapitalize="none" autoCorrect={false} secureTextEntry={secure} style={styles.input} /></View>; }
function ErrorText({ error }: { error?: string }) { return error ? <Text style={styles.error}>{error}</Text> : null; }
const styles = StyleSheet.create({ screen: { flex: 1, backgroundColor: colors.primary, justifyContent: 'center', paddingHorizontal: 20 }, hero: { alignItems: 'center', marginBottom: 25 }, logo: { width: 64, height: 64, borderRadius: 20, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }, brand: { color: '#fff', fontSize: 26, fontWeight: '800', marginTop: 12 }, tagline: { color: '#D9E8FF', marginTop: 5 }, card: { backgroundColor: '#fff', borderRadius: 22, padding: 22 }, eyebrow: { color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 1.5 }, title: { color: colors.text, fontSize: 24, fontWeight: '800', marginTop: 5 }, help: { color: colors.muted, lineHeight: 19, fontSize: 12, marginTop: 6, marginBottom: 12 }, field: { height: 50, marginTop: 11, borderRadius: 12, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13 }, input: { flex: 1, color: colors.text, marginLeft: 9 }, button: { height: 51, borderRadius: 12, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginTop: 18 }, buttonText: { color: '#fff', fontWeight: '800' }, error: { color: colors.danger, fontSize: 11, marginTop: 10 }, footer: { color: '#C9DDFB', fontSize: 11, textAlign: 'center', marginTop: 20 } });
