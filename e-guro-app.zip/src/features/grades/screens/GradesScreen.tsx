import { useMutation, useQuery } from '@apollo/client';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ErrorState, LoadingState, ScreenHeader } from '@/shared/components/ui';
import { GRADE_ROSTER_QUERY } from '../graphql/queries/getGradeRoster';
import { SAVE_GRADES_MUTATION } from '../graphql/mutations/saveGrades';
import { colors } from '@/core/theme';
import { Classroom, RosterStudent } from '@/core/types';

type Scores = Record<string, { quiz: string; activity: string; exam: string }>;
type Detail = { classDetail: { classroom: Classroom; roster: RosterStudent[] } };

export default function GradesScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const [quarter, setQuarter] = useState(1);
  const [scores, setScores] = useState<Scores>({});
  const { data, loading, error, refetch } = useQuery<Detail>(GRADE_ROSTER_QUERY, { variables: { id, quarter }, skip: !id });
  const [save, { loading: saving }] = useMutation(SAVE_GRADES_MUTATION);

  useEffect(() => {
    if (!data) return;
    setScores(Object.fromEntries(data.classDetail.roster.map(({ student, grade }) => [student.id, { quiz: String(grade?.quiz ?? ''), activity: String(grade?.activity ?? ''), exam: String(grade?.exam ?? '') }])));
  }, [data]);

  const complete = useMemo(() => data?.classDetail.roster.every(({ student }) => Object.values(scores[student.id] ?? {}).every((v) => v !== '' && Number(v) >= 0 && Number(v) <= 100)) ?? false, [data, scores]);
  function setScore(studentId: string, key: 'quiz' | 'activity' | 'exam', value: string) { if (/^\d{0,3}(\.\d?)?$/.test(value)) setScores((current) => ({ ...current, [studentId]: { ...(current[studentId] ?? { quiz: '', activity: '', exam: '' }), [key]: value } })); }
  function final(studentId: string) { const s = scores[studentId]; if (!s || Object.values(s).some((v) => v === '')) return '—'; return (Number(s.quiz) * .2 + Number(s.activity) * .3 + Number(s.exam) * .5).toFixed(1); }
  async function submit() {
    if (!complete || !data) return Alert.alert('Complete the scores', 'Enter a value from 0 to 100 in every field.');
    try {
      const entries = data.classDetail.roster.map(({ student }) => ({ studentId: student.id, quiz: Number(scores[student.id]!.quiz), activity: Number(scores[student.id]!.activity), exam: Number(scores[student.id]!.exam) }));
      await save({ variables: { input: { classroomId: id, quarter, entries } } });
      Alert.alert('Grades saved', `${entries.length} student grades were updated.`);
      await refetch();
    } catch (saveError) { Alert.alert('Grades not saved', saveError instanceof Error ? saveError.message : 'Try again.'); }
  }

  return <KeyboardAvoidingView style={[styles.screen, { paddingTop: insets.top }]} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <ScreenHeader title="Encode Grades" subtitle={data?.classDetail.classroom.displayName} onBack={router.back} />
    {loading && !data ? <LoadingState /> : error && !data ? <ErrorState message={error.message} retry={refetch} /> : <>
      <View style={styles.quarters}>{[1, 2, 3, 4].map((value) => <Pressable key={value} onPress={() => setQuarter(value)} style={[styles.quarter, quarter === value && styles.quarterActive]}><Text style={[styles.quarterText, quarter === value && styles.quarterTextActive]}>Q{value}</Text></Pressable>)}</View>
      <View style={styles.weights}><Text style={[styles.headName, { flex: 1 }]}>Student</Text><Text style={styles.headScore}>Quiz{`\n`}20%</Text><Text style={styles.headScore}>Activity{`\n`}30%</Text><Text style={styles.headScore}>Exam{`\n`}50%</Text><Text style={styles.headGrade}>Grade</Text></View>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.table}>
        {data!.classDetail.roster.map(({ student }, index) => <View key={student.id} style={[styles.row, index > 0 && styles.border]}><View style={styles.nameWrap}><Text numberOfLines={1} style={styles.name}>{student.lastName}, {student.firstName}</Text><Text style={styles.studentId}>{student.studentNo}</Text></View>{(['quiz', 'activity', 'exam'] as const).map((key) => <TextInput key={key} value={scores[student.id]?.[key] ?? ''} onChangeText={(v) => setScore(student.id, key, v)} keyboardType="decimal-pad" selectTextOnFocus style={styles.score} maxLength={5} />)}<Text style={[styles.final, Number(final(student.id)) < 75 && styles.low]}>{final(student.id)}</Text></View>)}
      </ScrollView>
      <View style={styles.footer}><Pressable disabled={saving} onPress={submit} style={[styles.save, (!complete || saving) && { opacity: .6 }]}><Text style={styles.saveText}>{saving ? 'Saving…' : 'Save Grades'}</Text></Pressable></View>
    </>}
  </KeyboardAvoidingView>;
}

const styles = StyleSheet.create({ screen: { flex: 1, backgroundColor: colors.background }, quarters: { flexDirection: 'row', margin: 14, padding: 4, borderRadius: 12, backgroundColor: '#E9EDF4' }, quarter: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 9 }, quarterActive: { backgroundColor: colors.surface }, quarterText: { color: colors.muted, fontWeight: '700' }, quarterTextActive: { color: colors.primary }, weights: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 9 }, headName: { color: colors.muted, fontSize: 10, fontWeight: '700' }, headScore: { width: 59, textAlign: 'center', color: colors.muted, fontSize: 9, lineHeight: 12 }, headGrade: { width: 50, textAlign: 'right', color: colors.muted, fontSize: 9 }, table: { backgroundColor: colors.surface, marginHorizontal: 10, borderRadius: 14, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 8, paddingBottom: 15 }, row: { minHeight: 62, flexDirection: 'row', alignItems: 'center' }, border: { borderTopWidth: 1, borderTopColor: colors.border }, nameWrap: { flex: 1, paddingRight: 5 }, name: { color: colors.text, fontSize: 11, fontWeight: '700' }, studentId: { color: colors.muted, fontSize: 9, marginTop: 3 }, score: { width: 52, height: 35, marginLeft: 7, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 8, textAlign: 'center', color: colors.text, fontSize: 12 }, final: { width: 50, textAlign: 'right', color: colors.success, fontWeight: '800', fontSize: 12 }, low: { color: colors.danger }, footer: { padding: 14, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border }, save: { backgroundColor: colors.primary, height: 50, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, saveText: { color: '#fff', fontWeight: '800', fontSize: 15 } });
