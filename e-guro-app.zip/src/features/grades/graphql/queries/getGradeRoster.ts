import { gql } from '@apollo/client';
import { CLASS_FIELDS } from '@/features/classes/graphql/fragments/classFields';
import { STUDENT_FIELDS } from '@/features/students/graphql/fragments/studentFields';

export const GRADE_ROSTER_QUERY = gql`
  ${CLASS_FIELDS}
  ${STUDENT_FIELDS}
  query GradeRoster($id: ID!, $date: String, $quarter: Int!) {
    classDetail(id: $id, date: $date, quarter: $quarter) {
      classroom { ...ClassFields }
      roster {
        student { ...StudentFields }
        attendance { id date checkedAt status }
        grade { id quarter quiz activity exam finalGrade }
      }
    }
  }
`;
