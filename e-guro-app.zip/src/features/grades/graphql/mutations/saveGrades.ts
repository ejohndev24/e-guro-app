import { gql } from '@apollo/client';

export const SAVE_GRADES_MUTATION = gql`
  mutation SaveGrades($input: SaveGradesInput!) {
    saveGrades(input: $input) { count grades { id quarter quiz activity exam finalGrade } }
  }
`;
