import { useQuery } from '@apollo/client';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Card, EmptyState, ErrorState, LoadingState } from '@/shared/components/ui';
import { CLASSES_QUERY } from '../graphql/queries/getClasses';
import { colors } from '@/core/theme';
import { Classroom } from '@/core/types';

export default function ClassesScreen() {
  const insets = useSafeAreaInsets();
  const { data, loading, error, refetch } = useQuery<{ classes: Classroom[] }>(CLASSES_QUERY);
  return <View style={[styles.screen, { paddingTop: insets.top }]}>
    <View style={styles.titleBar}><View><Text style={styles.eyebrow}>TEACHING</Text><Text style={styles.title}>My Classes</Text></View><Pressable onPress={() => router.push('/scanner')} style={styles.scan}><Ionicons name="qr-code" size={20} color="#fff" /></Pressable></View>
    {loading && !data ? <LoadingState /> : error && !data ? <ErrorState message={error.message} retry={refetch} /> :
      <FlatList data={data?.classes} keyExtractor={(item) => item.id} contentContainerStyle={styles.list} onRefresh={refetch} refreshing={loading}
        ListEmptyComponent={<EmptyState title="No classes yet" detail="Create a class in the database, then pull to refresh." />}
        renderItem={({ item }) => <ClassCard item={item} />} />}
  </View>;
}

function ClassCard({ item }: { item: Classroom }) {
  return <Pressable onPress={() => router.push(`/class/${item.id}`)}>
    <Card style={styles.card}>
      <View style={styles.cardTop}><View style={styles.book}><Ionicons name="book" size={24} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.subject}>{item.subject}</Text><Text style={styles.grade}>Grade {item.gradeLevel} · {item.section}</Text></View><Ionicons name="chevron-forward" size={20} color="#AAB3C1" /></View>
      <View style={styles.divider} />
      <View style={styles.info}><Info icon="time-outline" text={`${formatTime(item.startTime)}–${formatTime(item.endTime)}`} /><Info icon="location-outline" text={item.room} /><Info icon="people-outline" text={`${item.studentCount} students`} /></View>
      <View style={styles.buttons}><Pressable onPress={() => router.push({ pathname: '/scanner', params: { classId: item.id } })} style={styles.secondary}><Ionicons name="qr-code-outline" size={17} color={colors.primary} /><Text style={styles.secondaryText}>Attendance</Text></Pressable><Pressable onPress={() => router.push(`/grades/${item.id}`)} style={styles.primary}><Ionicons name="create-outline" size={17} color="#fff" /><Text style={styles.primaryText}>Grades</Text></Pressable></View>
    </Card>
  </Pressable>;
}

function Info({ icon, text }: { icon: keyof typeof Ionicons.glyphMap; text: string }) { return <View style={styles.infoItem}><Ionicons name={icon} size={15} color={colors.muted} /><Text style={styles.infoText}>{text}</Text></View>; }
function formatTime(time: string) { const [h, m] = time.split(':'); const hour = Number(h); return `${hour % 12 || 12}:${m} ${hour >= 12 ? 'PM' : 'AM'}`; }

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background }, titleBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20 }, eyebrow: { color: colors.primary, fontSize: 10, letterSpacing: 1.5, fontWeight: '800' }, title: { fontSize: 27, fontWeight: '800', color: colors.text, marginTop: 2 }, scan: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' }, list: { paddingHorizontal: 16, paddingBottom: 30, gap: 12 }, card: { padding: 16 }, cardTop: { flexDirection: 'row', alignItems: 'center' }, book: { width: 48, height: 48, borderRadius: 14, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1, marginLeft: 13 }, subject: { fontSize: 16, color: colors.text, fontWeight: '800' }, grade: { color: colors.muted, marginTop: 4, fontSize: 12 }, divider: { height: 1, backgroundColor: colors.border, marginVertical: 14 }, info: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 }, infoItem: { flexDirection: 'row', alignItems: 'center', gap: 5 }, infoText: { fontSize: 11, color: colors.muted }, buttons: { flexDirection: 'row', gap: 10, marginTop: 15 }, secondary: { flex: 1, height: 40, borderRadius: 10, borderWidth: 1, borderColor: '#BBD2F8', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6 }, secondaryText: { color: colors.primary, fontWeight: '700', fontSize: 12 }, primary: { flex: 1, height: 40, borderRadius: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6 }, primaryText: { color: '#fff', fontWeight: '700', fontSize: 12 },
});
