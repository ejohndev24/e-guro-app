import { useMutation, useQuery } from '@apollo/client';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, ErrorState, LoadingState, ScreenHeader, StatusPill } from '@/shared/components/ui';
import { CLASS_DETAIL_QUERY } from '../graphql/queries/getClassDetail';
import { SET_ATTENDANCE_MUTATION } from '@/features/attendance/graphql/mutations/attendanceMutations';
import { colors } from '@/core/theme';
import { Classroom, RosterStudent } from '@/core/types';

type Detail = { classDetail: { classroom: Classroom; roster: RosterStudent[] } };

export default function ClassDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState('');
  const date = new Date().toISOString().slice(0, 10);
  const { data, loading, error, refetch } = useQuery<Detail>(CLASS_DETAIL_QUERY, { variables: { id, date, quarter: 1 }, skip: !id });
  const [setAttendance, { loading: saving }] = useMutation(SET_ATTENDANCE_MUTATION);
  const filtered = data?.classDetail.roster.filter(({ student }) => student.fullName.toLowerCase().includes(search.toLowerCase()) || student.studentNo.includes(search)) ?? [];

  async function update(studentId: string, status: 'PRESENT' | 'ABSENT') {
    try {
      await setAttendance({ variables: { classroomId: id, studentId, date, status }, refetchQueries: [{ query: CLASS_DETAIL_QUERY, variables: { id, date, quarter: 1 } }] });
    } catch (mutationError) { Alert.alert('Attendance not saved', mutationError instanceof Error ? mutationError.message : 'Try again.'); }
  }

  return <View style={[styles.screen, { paddingTop: insets.top }]}>
    <ScreenHeader title={data?.classDetail.classroom.subject ?? 'Class list'} subtitle={data ? `Grade ${data.classDetail.classroom.gradeLevel} · ${data.classDetail.classroom.section}` : undefined} onBack={router.back} action={<Pressable onPress={() => router.push({ pathname: '/scanner', params: { classId: id } })}><Ionicons name="qr-code-outline" size={23} color={colors.primary} /></Pressable>} />
    {loading && !data ? <LoadingState /> : error && !data ? <ErrorState message={error.message} retry={refetch} /> : <>
      <View style={styles.summary}><View><Text style={styles.summaryValue}>{data!.classDetail.roster.length}</Text><Text style={styles.summaryLabel}>Students</Text></View><View style={styles.summaryDivider} /><View><Text style={[styles.summaryValue, { color: colors.success }]}>{data!.classDetail.roster.filter((x) => x.attendance?.status === 'PRESENT').length}</Text><Text style={styles.summaryLabel}>Present today</Text></View><Pressable onPress={() => router.push(`/grades/${id}`)} style={styles.gradeButton}><Ionicons name="create-outline" size={17} color="#fff" /><Text style={styles.gradeButtonText}>Grades</Text></Pressable></View>
      <View style={styles.search}><Ionicons name="search" size={18} color={colors.muted} /><TextInput value={search} onChangeText={setSearch} placeholder="Search student…" placeholderTextColor="#98A2B3" style={styles.input} /></View>
      <FlatList data={filtered} keyExtractor={(item) => item.student.id} contentContainerStyle={styles.list} refreshing={loading || saving} onRefresh={refetch}
        renderItem={({ item, index }) => <View style={[styles.row, index > 0 && styles.border]}><Text style={styles.index}>{index + 1}</Text><Pressable onPress={() => router.push(`/student/${item.student.id}`)}><Avatar name={item.student.fullName} size={40} /></Pressable><Pressable onPress={() => router.push(`/student/${item.student.id}`)} style={styles.copy}><Text style={styles.name}>{item.student.fullName}</Text><Text style={styles.id}>ID: {item.student.studentNo}</Text></Pressable>{item.attendance ? <Pressable onPress={() => update(item.student.id, item.attendance?.status === 'PRESENT' ? 'ABSENT' : 'PRESENT')}><StatusPill status={item.attendance.status} /></Pressable> : <View style={styles.markButtons}><Pressable onPress={() => update(item.student.id, 'PRESENT')} style={styles.present}><Ionicons name="checkmark" size={17} color={colors.success} /></Pressable><Pressable onPress={() => update(item.student.id, 'ABSENT')} style={styles.absent}><Ionicons name="close" size={17} color={colors.danger} /></Pressable></View>}</View>} />
    </>}
  </View>;
}

const styles = StyleSheet.create({ screen: { flex: 1, backgroundColor: colors.background }, summary: { margin: 16, padding: 15, borderRadius: 15, flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }, summaryValue: { color: colors.text, fontSize: 19, fontWeight: '800' }, summaryLabel: { color: colors.muted, fontSize: 10, marginTop: 2 }, summaryDivider: { width: 1, height: 38, backgroundColor: colors.border, marginHorizontal: 18 }, gradeButton: { marginLeft: 'auto', backgroundColor: colors.primary, height: 38, borderRadius: 10, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 5 }, gradeButtonText: { color: '#fff', fontWeight: '700', fontSize: 12 }, search: { marginHorizontal: 16, marginBottom: 10, height: 43, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, borderRadius: 12, backgroundColor: '#EEF1F6' }, input: { flex: 1, color: colors.text, marginLeft: 8 }, list: { marginHorizontal: 16, paddingHorizontal: 13, paddingBottom: 30, backgroundColor: colors.surface, borderRadius: 15, borderWidth: 1, borderColor: colors.border }, row: { minHeight: 67, flexDirection: 'row', alignItems: 'center', gap: 10 }, border: { borderTopWidth: 1, borderTopColor: colors.border }, index: { color: colors.muted, width: 15, fontSize: 11, textAlign: 'center' }, copy: { flex: 1 }, name: { color: colors.text, fontSize: 13, fontWeight: '700' }, id: { color: colors.muted, fontSize: 10, marginTop: 3 }, markButtons: { flexDirection: 'row', gap: 5 }, present: { width: 31, height: 31, borderRadius: 9, backgroundColor: colors.successSoft, alignItems: 'center', justifyContent: 'center' }, absent: { width: 31, height: 31, borderRadius: 9, backgroundColor: colors.dangerSoft, alignItems: 'center', justifyContent: 'center' } });
