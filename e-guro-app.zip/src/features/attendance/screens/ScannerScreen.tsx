import { useMutation, useQuery } from '@apollo/client';
import { Ionicons } from '@expo/vector-icons';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ScreenHeader } from '@/shared/components/ui';
import { ATTENDANCE_CLASSES_QUERY } from '../graphql/queries/getAttendanceClasses';
import { MARK_ATTENDANCE_MUTATION } from '../graphql/mutations/attendanceMutations';
import { colors } from '@/core/theme';
import { Classroom } from '@/core/types';

export default function ScannerScreen() {
  const params = useLocalSearchParams<{ classId?: string }>();
  const insets = useSafeAreaInsets();
  const [permission, requestPermission] = useCameraPermissions();
  const { data } = useQuery<{ classes: Classroom[] }>(ATTENDANCE_CLASSES_QUERY);
  const [classId, setClassId] = useState(params.classId ?? '');
  const [mode, setMode] = useState<'scan' | 'manual'>('scan');
  const [manualCode, setManualCode] = useState('');
  const [locked, setLocked] = useState(false);
  const [lastCode, setLastCode] = useState<string>();
  const [mark, { loading }] = useMutation(MARK_ATTENDANCE_MUTATION);
  useEffect(() => { if (!classId && data?.classes[0]) setClassId(data.classes[0].id); }, [classId, data]);
  const selected = data?.classes.find((item) => item.id === classId);

  async function record(qrCode: string) {
    if (!classId || locked || loading) return;
    setLocked(true);
    try {
      await mark({ variables: { input: { classroomId: classId, qrCode: qrCode.trim(), date: new Date().toISOString().slice(0, 10), status: 'PRESENT' } } });
      setLastCode(qrCode);
      setManualCode('');
    } catch (scanError) {
      Alert.alert('Could not record attendance', scanError instanceof Error ? scanError.message : 'Check the code and try again.');
      setLocked(false);
    }
  }

  return <View style={[styles.screen, { paddingTop: insets.top }]}>
    <ScreenHeader title="QR Attendance Scanner" subtitle={selected?.displayName} onBack={router.back} />
    <View style={styles.tabs}><Pressable onPress={() => setMode('scan')} style={[styles.tab, mode === 'scan' && styles.tabActive]}><Text style={[styles.tabText, mode === 'scan' && styles.tabTextActive]}>Scan QR</Text></Pressable><Pressable onPress={() => setMode('manual')} style={[styles.tab, mode === 'manual' && styles.tabActive]}><Text style={[styles.tabText, mode === 'manual' && styles.tabTextActive]}>Manual</Text></Pressable></View>
    <View style={styles.classPicker}><Text style={styles.pickerLabel}>Class</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>{data?.classes.map((item) => <Pressable key={item.id} onPress={() => { setClassId(item.id); setLocked(false); setLastCode(undefined); }} style={[styles.chip, classId === item.id && styles.chipActive]}><Text style={[styles.chipText, classId === item.id && styles.chipTextActive]}>{item.subject}</Text></Pressable>)}</ScrollView></View>
    {mode === 'scan' ? <View style={styles.cameraWrap}>
      {!permission?.granted ? <View style={styles.permission}><Ionicons name="camera-outline" size={45} color={colors.muted} /><Text style={styles.permissionTitle}>Camera access is needed</Text><Text style={styles.permissionText}>The camera is used only to read student QR codes.</Text><Pressable onPress={requestPermission} style={styles.allow}><Text style={styles.allowText}>Allow camera</Text></Pressable></View> : <CameraView style={StyleSheet.absoluteFill} facing="back" barcodeScannerSettings={{ barcodeTypes: ['qr'] }} onBarcodeScanned={locked ? undefined : ({ data: code }) => record(code)} />}
      {permission?.granted && <><View style={styles.overlay} pointerEvents="none"><View style={styles.frame}><View style={[styles.corner, styles.tl]} /><View style={[styles.corner, styles.tr]} /><View style={[styles.corner, styles.bl]} /><View style={[styles.corner, styles.br]} /></View><Text style={styles.instruction}>Position the student's QR code inside the frame.</Text></View>{lastCode && <View style={styles.success}><Ionicons name="checkmark-circle" size={36} color={colors.success} /><View style={{ flex: 1 }}><Text style={styles.successTitle}>Attendance recorded</Text><Text style={styles.successCode}>{lastCode}</Text></View><Pressable onPress={() => { setLocked(false); setLastCode(undefined); }} style={styles.again}><Text style={styles.againText}>Scan next</Text></Pressable></View>}</>}
    </View> : <View style={styles.manual}><View style={styles.manualIcon}><Ionicons name="keypad-outline" size={28} color={colors.primary} /></View><Text style={styles.manualTitle}>Enter the QR value</Text><Text style={styles.manualHelp}>Seeded codes look like STUDENT:2024001</Text><TextInput value={manualCode} onChangeText={setManualCode} autoCapitalize="characters" autoCorrect={false} placeholder="STUDENT:2024001" placeholderTextColor="#9AA5B4" style={styles.codeInput} /><Pressable disabled={!manualCode.trim() || loading} onPress={() => record(manualCode)} style={[styles.submit, (!manualCode.trim() || loading) && { opacity: .5 }]}><Text style={styles.submitText}>{loading ? 'Recording…' : 'Mark Present'}</Text></Pressable>{lastCode && <Pressable onPress={() => { setLocked(false); setLastCode(undefined); }}><Text style={styles.reset}>Attendance saved · Enter another</Text></Pressable>}</View>}
  </View>;
}

const styles = StyleSheet.create({ screen: { flex: 1, backgroundColor: colors.background }, tabs: { height: 50, flexDirection: 'row', paddingHorizontal: 16, backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border }, tab: { flex: 1, alignItems: 'center', justifyContent: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' }, tabActive: { borderBottomColor: colors.primary }, tabText: { color: colors.muted, fontWeight: '600', fontSize: 12 }, tabTextActive: { color: colors.primary }, classPicker: { padding: 12, backgroundColor: colors.surface }, pickerLabel: { color: colors.muted, fontSize: 9, fontWeight: '800', letterSpacing: 1, marginBottom: 7 }, chip: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 18, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border }, chipActive: { backgroundColor: colors.primarySoft, borderColor: '#B7D1F8' }, chipText: { color: colors.muted, fontSize: 11, fontWeight: '600' }, chipTextActive: { color: colors.primary }, cameraWrap: { flex: 1, backgroundColor: '#111' }, overlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,.25)' }, frame: { width: 235, height: 235, marginTop: -65 }, corner: { position: 'absolute', width: 38, height: 38, borderColor: '#fff' }, tl: { left: 0, top: 0, borderLeftWidth: 4, borderTopWidth: 4, borderTopLeftRadius: 8 }, tr: { right: 0, top: 0, borderRightWidth: 4, borderTopWidth: 4, borderTopRightRadius: 8 }, bl: { left: 0, bottom: 0, borderLeftWidth: 4, borderBottomWidth: 4, borderBottomLeftRadius: 8 }, br: { right: 0, bottom: 0, borderRightWidth: 4, borderBottomWidth: 4, borderBottomRightRadius: 8 }, instruction: { color: '#fff', textAlign: 'center', fontSize: 13, marginTop: 25, width: 260 }, permission: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background, padding: 30 }, permissionTitle: { color: colors.text, fontSize: 17, fontWeight: '800', marginTop: 13 }, permissionText: { color: colors.muted, textAlign: 'center', marginTop: 7 }, allow: { backgroundColor: colors.primary, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 11, marginTop: 17 }, allowText: { color: '#fff', fontWeight: '700' }, success: { position: 'absolute', left: 14, right: 14, bottom: 20, backgroundColor: '#fff', borderRadius: 15, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10 }, successTitle: { color: colors.text, fontWeight: '800', fontSize: 13 }, successCode: { color: colors.muted, fontSize: 10, marginTop: 2 }, again: { backgroundColor: colors.successSoft, borderRadius: 9, padding: 9 }, againText: { color: colors.success, fontWeight: '700', fontSize: 11 }, manual: { margin: 18, backgroundColor: colors.surface, borderRadius: 18, borderWidth: 1, borderColor: colors.border, padding: 22, alignItems: 'center' }, manualIcon: { width: 54, height: 54, borderRadius: 16, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, manualTitle: { color: colors.text, fontSize: 17, fontWeight: '800', marginTop: 13 }, manualHelp: { color: colors.muted, fontSize: 11, marginTop: 5 }, codeInput: { width: '100%', height: 48, borderRadius: 11, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 13, color: colors.text, marginTop: 20 }, submit: { width: '100%', height: 48, borderRadius: 11, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginTop: 11 }, submitText: { color: '#fff', fontWeight: '800' }, reset: { color: colors.success, fontWeight: '700', fontSize: 11, marginTop: 14 } });
