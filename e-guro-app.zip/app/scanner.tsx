export { default } from '@/features/attendance/screens/ScannerScreen';
