import { ApolloProvider } from '@apollo/client';
import { router, Stack, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { apolloClient } from '@/core/apollo/client';
import { colors } from '@/core/theme';
import { AuthProvider, useAuth } from '@/core/auth/AuthProvider';

export default function RootLayout() {
  return (
    <ApolloProvider client={apolloClient}>
      <AuthProvider><SafeAreaProvider><Navigation /></SafeAreaProvider></AuthProvider>
    </ApolloProvider>
  );
}

function Navigation() {
  const { token, loading } = useAuth();
  const segments = useSegments();
  useEffect(() => {
    if (loading) return;
    const onLogin = segments[0] === 'login';
    if (!token && !onLogin) router.replace('/login');
    if (token && onLogin) router.replace('/');
  }, [token, loading, segments]);
  if (loading) return null;
  return <><StatusBar style="dark" /><Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}>
          <Stack.Screen name="login" />
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="class/[id]" />
          <Stack.Screen name="grades/[id]" />
          <Stack.Screen name="student/[id]" />
          <Stack.Screen name="scanner" options={{ presentation: 'fullScreenModal' }} />
        </Stack></>;
}
